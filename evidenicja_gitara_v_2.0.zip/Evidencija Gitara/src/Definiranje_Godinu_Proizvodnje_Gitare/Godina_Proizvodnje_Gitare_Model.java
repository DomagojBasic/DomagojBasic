package Definiranje_Godinu_Proizvodnje_Gitare;

import java.io.Serializable;

public class Godina_Proizvodnje_Gitare_Model implements Serializable {

		private String Godina_Proizvodnje;

		public String getGodina_Proizvodnje() {
			return Godina_Proizvodnje;
		}

		public void setGodina_Proizvodnje(String godina_Proizvodnje) {
			Godina_Proizvodnje = godina_Proizvodnje;
		}

		
		
}
