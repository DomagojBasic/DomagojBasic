package Definiranje_Broja_Zica_Gitare;

import java.io.Serializable;

public class Broj_Zica_Gitare_Model implements Serializable{

	private String Broj_Zica;

	public String getBroj_Zica() {
		return Broj_Zica;
	}

	public void setBroj_Zica(String broj_Zica) {
		Broj_Zica = broj_Zica;
	}

	
	
}
